local ResolvedPatternType = require("at.petrak.hexcasting.api.casting.eval.ResolvedPatternType")
local SpellContinuation = require("at.petrak.hexcasting.api.casting.eval.vm.SpellContinuation")
local HexEvalSounds = require("at.petrak.hexcasting.common.lib.hex.HexEvalSounds")
local OperationResult = require("at.petrak.hexcasting.api.casting.eval.OperationResult")
local GarbageIota = require("at.petrak.hexcasting.api.casting.iota.GarbageIota")

local Mishap = {}

Mishap.Mishap = function(env, image, stack)
    local stack = image.stack:toArray()
    table.insert(stack, GarbageIota())

    local newImage = image:copy(stack, image.parenCount, image.parenthesized, image.escapeNext, image.opsConsumed + 1, image.userData)
    return OperationResult(newImage, {}, SpellContinuation, HexEvalSounds.MISHAP)
end

return Mishap