# hexnoun!
a [hexcasting](https://modrinth.com/mod/hex-casting) addon made using [allium](https://modrinth.com/mod/allium)

it depends on [hex](https://modrinth.com/mod/hex-casting)/[hexal](https://modrinth.com/mod/hexal)/[moreiotas](https://modrinth.com/mod/moreiotas)/[hexical](https://modrinth.com/mod/hexical/)/[allium](https://modrinth.com/mod/allium) at the moment iirc

it's made for the hexjam, i started it just a few hours before the due date at like midnight while never having used this before, so it's very unfinished at the moment

but it does have a pattern to convert between [hexical](https://modrinth.com/mod/hexical/) and [hexal](https://modrinth.com/mod/hexal)([moreiotas](https://modrinth.com/mod/moreiotas)) types, and i was planning on having that pattern convert between a few more types

to run this, you can clone this repo and put the folder right into .minecraft/allium, or put the zip from the releases page into .minecraft/allium

![image](https://github.com/user-attachments/assets/eda2b844-3612-45af-8cec-c5efef20b11b)

![image](https://github.com/user-attachments/assets/f6adbc7b-d859-4f0f-b779-b7dc91e3c503)

(here's the convert pattern, patchouli isn't set up yet)
