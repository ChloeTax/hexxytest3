if package.environment == "client" then return end

require("Registry.hexnounPatternRegistry")
